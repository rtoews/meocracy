<?php
$pass = 'yuletide';
print "Pass: $pass<br/>";
?>

