<?php

$title='Meocracy';

include('includes/head.php');

echo "

	<ul data-role='listview' data-inset='false' data-theme='a'  data-divider-theme='a'>
		<li data-role='list-divider'>Search</li>
	</ul>

<br><br>

	<form name='search'>
		<input type='search' name='search' id='search' value='' />
	</form>

";

include('includes/footer.php');

?>