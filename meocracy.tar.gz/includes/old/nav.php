
</div>
<!--/content-primary -->



<div class="content-secondary">
	<div data-role="collapsible" data-collapsed="true" data-theme="b" data-content-theme="d">	
			<ul data-role="listview"  data-theme="c" data-dividertheme="a">
				<li<?php if ($section=='home') echo " data-theme='b'";?>><a href="index.php">Home</a></li>
				<li<?php if ($section=='feedback') echo " data-theme='b'";?>><a href="feedback.php">My Feedback</a></li> 
				<li<?php if ($section=='announcements') echo " data-theme='b'";?>><a href="announcements.php">My Announcements</a></li> 
				<li<?php if ($section=='legislation') echo " data-theme='b'";?>><a href="legislation.php">My Legislation</a></li>
				<li<?php if ($section=='messages') echo " data-theme='b'";?>><a href="messages.php">My Messages</a></li>
				<li<?php if ($section=='office') echo " data-theme='b'";?>><a href="office.php">My Office</a></li>
				<li<?php if ($section=='me') echo " data-theme='b'";?>><a href="me.php">About Me</a></li>
			</ul>
		</div>
	</div>
</div>
<!-- /content -->