<?php 

echo "

	</div>

	<div data-role='footer' class='footer' data-theme='c'>
		<img src='/images/logo_sm.png' height='20' width='92'>
	</div>

<!-- /page -->
</div>

</body>
</html>"; 

?>

