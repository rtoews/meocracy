<div data-inline='true' data-type='horizontal'>
	<a href="#" data-role='button'  data-icon="arrow-r">Send a message to <?php echo $office; ?></a>
</div>