<?

$conn = mysql_connect("meocracy2.db.3410806.hostedresource.com","meocracy2" , "Badlsd22") or die(mysql_error());
mysql_select_db('meocracy2', $conn) or die(mysql_error());

?>
