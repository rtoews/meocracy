
<?php
echo "<li><a href='".$office_url."'><img src='photos/".$official_photo."' />";
echo "<h3>".$official_title." ".$official_name_first." ".$official_name_last."</h3>\n"; 
echo "<p>".$office_top.", ".$office_sub."</p></a></li>\n</ul>";
?>