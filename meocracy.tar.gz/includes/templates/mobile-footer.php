    </div>
    <!-- div data-role='footer' class='footer' data-theme='a' data-position='fixed'>
        <img src='../images/logo_sm.png' height='20' width='92'>
    </div -->

<!-- /page -->
</div>
</body>
</html>
