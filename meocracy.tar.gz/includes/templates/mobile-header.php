<body> 
<div data-role='page' data-title='Meocracy' data-theme='a'>
    <div data-role='header' data-theme='a'>
        <div data-role='navbar'>

            <ul>
            <li><a href='index.php' data-icon='home' data-theme='a'>Home</a></li>
            <li><a href='search.php' data-icon='search' data-theme='a'>Search</a></li>
            <li><a href='alert_manager.php' data-icon='alert' data-theme='a'>Alerts</a></li>
            <li><a href='settings.php' data-icon='gear' data-theme='a'>Settings</a></li>
            </ul>

        </div>
    </div><!-- /header -->

    <div data-role='content'>
