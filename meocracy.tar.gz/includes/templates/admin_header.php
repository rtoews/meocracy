<body>
<div class='wrapper'>
    <div class='header_fullwidth'>
        <div class='header'>
            <img class='header_image' src='/images/photos/logo/city_aliso_viejo.png'>
            <h1>City of Aliso Viejo</h1>
        </div>
    </div>

    <div class='page'>
        <div class="column_left">
            <div class="nav"><a href="index">Dashboard</a></div>
            <div class="nav"><a href="announcement">Announcements</a></div>
            <div class="nav"><a href="legislation">Legislation</a></div>
            <div class="nav"><a href="message">Messages</a></div>
            <div class="nav"><a href="setup">Setup</a></div>
        </div>

        <div class="column_right">
