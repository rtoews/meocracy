<?php 

echo "
<!DOCTYPE html> 
<html> 
<head>

<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />

<META NAME='ROBOTS' CONTENT='NOINDEX, NOFOLLOW'>

<title>".$page_title."</title>  

<link type='text/css' href='css/layout.css' rel='stylesheet' />
<link type='text/css' href='css/colors.css' rel='stylesheet' />
<link type='text/css' href='css/header.css' rel='stylesheet' />
<link type='text/css' href='css/nav.css' rel='stylesheet' />
<link type='text/css' href='css/results.css' rel='stylesheet' />
<link type='text/css' href='css/charts.css' rel='stylesheet' />
<link type='text/css' href='css/forms.css' rel='stylesheet' />
<link type='text/css' href='css/images.css' rel='stylesheet' />

<script type='text/javascript' src='https://www.google.com/jsapi'></script>

</head> 
<body> 

<center>

<div class='wrapper'>

<div class='header_fullwidth'>
	<div class='header'>
		<img class='header_image' src='/photos/logo/city_aliso_viejo.png'>
		<h1>City of Aliso Viejo</h1>
	</div>
</div>

<div class='page'>

";

?>