<div class="column_left">
    <div class="nav"><a href="index">Dashboard</a></div>
    <div class="nav"><a href="announcement">Announcements</a></div>
    <div class="nav"><a href="legislation">Legislation</a></div>
    <div class="nav"><a href="message">Messages</a></div>
    <div class="nav"><a href="setup">Setup</a></div>
</div>

<div class="column_right">
