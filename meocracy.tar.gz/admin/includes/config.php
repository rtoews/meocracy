<?php

$entity_id='1'; 
$entity_name='Aliso Viejo'; 

?>