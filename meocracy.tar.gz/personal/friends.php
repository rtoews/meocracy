<?php
$friends = array(
    array('first' => 'George', 'last' => 'Brannan', 'email' => 'george.brannan@meocracy.com', 'phone' => '3605551212'),
    array('first' => 'Carmilla', 'last' => 'Spencer', 'email' => 'carmilla.spencer@meocracy.com', 'phone' => '3605551212'),
    array('first' => 'Aidan', 'last' => 'Owens', 'email' => 'aidan.owens@meocracy.com', 'phone' => '3605551212'),
    array('first' => 'Charles', 'last' => 'Swarts', 'email' => 'charles.swarts@meocracy.com', 'phone' => '3605551212'),
    array('first' => 'Chuck', 'last' => 'Shorley', 'email' => 'chuck.shorley@meocracy.com', 'phone' => '3605551212'),
    array('first' => 'Brandon', 'last' => 'Forrest', 'email' => 'brandon.forrest@meocracy.com', 'phone' => '3605551212'),
    array('first' => 'Blake', 'last' => 'Reistad', 'email' => 'blake.reistad@meocracy.com', 'phone' => '3605551212'),
    array('first' => 'Darren', 'last' => 'Demchuck', 'email' => 'darren.demchuck@meocracy.com', 'phone' => '3605551212'),
    array('first' => 'Kim', 'last' => 'Esther', 'email' => 'kim.esther@meocracy.com', 'phone' => '3605551212'),
    array('first' => 'Grace', 'last' => 'Caslow', 'email' => 'grace.caslow@meocracy.com', 'phone' => '3605551212'),
    
);
?>
